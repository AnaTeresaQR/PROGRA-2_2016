
package AbstractFactoryPackage;

/**
 *Interface implemented by concrete classes
 * @author Kevin Quiros
 * @author Vanessa Bolaños
 * @version 1.0
 */

public interface Car {
    
    /**
     * this method allows the car to print a unique message depending of who calls it.
     */
    
    public void drive();
    
    /**
     *This method  Calculates depreciation of a car by year
     */
    
    public double depreciation();
}
