package AbstractFactoryPackage;

/**
 * This class implements Car interface, so does every concrete class
 * representing a car.
 * @author Kevin Quiros
 * @author Vanessa Bolaños
 * @version 1.0
 */
public class Brio implements Car {

    private final double DEPRETATION = 500; // Depretation of the car for age 
    private int longevity; //Longevity of the car
    public final double price = 5000; // Price of the car 

    /**
     * Method Contructuctor
     * @param longevity
     */
    public Brio(int longevity) {
        this.longevity = longevity;
    }

    public double getPrice() {
        return price;
    }

    public int getLongevity() {
        return longevity;
    }
    
    

    
    /**
     * Method implemented to prove that a Brio object has been succesfully
     * created and can execute its methods.
     */
    public void drive() {
        System.out.println("Brio car just created!");
    }

    /**
     * Method that calculates the depreciation of a vehicle
     *
     * @return depreciation
     */
    public double depreciation() {
        return price - (longevity * DEPRETATION);
    }

}
