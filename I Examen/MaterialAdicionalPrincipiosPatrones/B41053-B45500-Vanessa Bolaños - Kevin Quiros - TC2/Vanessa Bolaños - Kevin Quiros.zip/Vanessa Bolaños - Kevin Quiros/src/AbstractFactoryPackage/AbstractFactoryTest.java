
package AbstractFactoryPackage;

/**
 * Interface Abstract Factory 
 * @author Kevin Quiros
 * @author Vanessa Bolaños
 * @version 1.0
 */
public class AbstractFactoryTest {

    /**
     *The start point in the application 
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        //Here are created the factories //
       CarFactory hyundaiFactory = FactoryProducer.getCarFactory("Hyundai");
       CarFactory hondaFactory = FactoryProducer.getCarFactory("Honda");
       String text = "\n****************************************************************************************************\n";
       
   
       Car brio = hondaFactory.createCar("Brio", 6 , "manual"); //An instance of interface Car is created, but it´s actually an object of type Brio.
       brio.drive();
       System.out.println("Price Car " + ((Brio)brio).getPrice());
        System.out.println("Vehicle age : " +((Brio)brio).getLongevity() );
       System.out.println("New price after  depreciation of the car is : " + brio.depreciation()+text);
       
        
       Car city = hondaFactory.createCar("City", 5 , "automatico"); // An instance of interface Car is created, but it´s actually an object of type City. 
       city.drive();
       System.out.println("Price Car " + ((City)city).getPrice());
       System.out.println("Vehicle age :" +((City)city).getLongevity());
       System.out.println("New price after  depreciation of the car is : " + city.depreciation()+ text);
 
       

       Car I10 = hyundaiFactory.createCar("I10",9 ,"automatico "); //Instance of interface Car is created, but it´s actually an object of type I10.
       I10.drive();
       System.out.println("Price Car " + (( I10)I10).getPRICE());
        System.out.println("Vehicle age : " + (( I10)I10).getLongevity());
       System.out.println("New price after  depreciation of the car is : " + brio.depreciation()+ text);
       I10.depreciation();
       
       
       Car I20 = hyundaiFactory.createCar("I20",7  , "manual");  //An instance of interface Car is created, but it´s actually an object of type I20.
       I20.drive();
       System.out.println("Price Car " + ((I20)I20).getPrice());
       System.out.println("Vehicle age: " + ((I20)I20).getLongevity());
       System.out.println("New price after  depreciation of the car is :  " + I20.depreciation()+ text);
     
    }
    
}
