
package AbstractFactoryPackage;

/**
 * Interface implemented by all concrete factories on the program.
 *@author Kevin Quiros
 * @author Vanessa Bolaños
 * @version 1.0
 */

public interface CarFactory {
    
    /**
     * this method is used to create a new car from its corresponding factory
     * 
     */
    
    public Car createCar(String type, int longevity ,  String transmission);
}
