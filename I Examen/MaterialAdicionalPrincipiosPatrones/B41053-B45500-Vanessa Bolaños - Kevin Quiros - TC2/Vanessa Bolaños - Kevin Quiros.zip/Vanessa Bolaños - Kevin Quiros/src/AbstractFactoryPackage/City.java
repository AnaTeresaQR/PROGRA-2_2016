
package AbstractFactoryPackage;

/**
 *This class implements Car interface, so does every concrete class representing a car.
 * @author Kevin Quiros Acosta 
 * @author Vanessa Bolaños Umaña 
 * @version 1.0
 */

public class City implements Car {
    
    private final double DEPRECIATION = 750; //depretation a car by Year
    private int longevity; // year bought the car
    private final double PRICE = 10000; // Price of the car 
    
    /**
     * Method Constructor of the City
     * @param longevity 
     */
    
    public City(int longevity) {
        this.longevity = longevity;
    }
    
    /**
     * Method implemented to prove that a City object has been succesfully created and can execute its methods.
     */
 
    public void drive() {
        System.out.println("City car just created!");
    }

    public double getPrice() {
        return PRICE;
    }
   
    public int getLongevity() {
        return longevity;
    }
     /**
      * This method  Calculates depreciation of a car by year
      * @return depretation 
      */  
    public double depreciation() {
        return (PRICE - (longevity * DEPRECIATION));
    }
    
}
