
package AbstractFactoryPackage;

/**
 *@autor Kevin Quiros Acosta 
 * @author Vanessa Bolaños Umaña 
 * @version 1.0
 */
public class FactoryProducer {

    /**
     * This method creates a new factory that is gonna buid cars.
     */
    
    public static CarFactory getCarFactory(String factory) {
        if (factory.equals("Honda")) {
            return new HondaCarFactory();
        } else if (factory.equals("Hyundai")) {
            return new HyundaiCarFactory();
        }
        return null;
    }
}
