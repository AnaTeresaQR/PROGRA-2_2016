
package AbstractFactoryPackage;

/**
 *
 * @author Kevin Quiros
 * @author Vanessa Bolaños
 * @version 1.0
 */

public class HondaCarFactory implements CarFactory {

    /**
     *this methods creates and returns a concrete object of type Car.
     *@return  Car
     */
    
    public Car createCar(String type, int longevity , String transmission) {
        try {
        if ("Brio".equalsIgnoreCase(type)) {
            return new Brio(longevity);
        }
        if ("City".equalsIgnoreCase(type)) {
            return new City(longevity);
        }
        }
        catch(Exception e ) {
                System.out.println("ERROR");
                }
        return null;
    }
}
