package AbstractFactoryPackage;

/**
 * This class implements Car interface, so does every concrete class
 * representing a car
 * @author Vanessa Bolaños Umaña
 * @author Kevin Quiros Acosta
 * @version 1.0
 */
public class I20 implements Car {

    private int longevity;  //year bought the car
    private String transmission; // type of  transmission of a car
    private final double DEPRECIATION = 500;
    private final double PRICE = 12000;
    private final double AUTOMATIC = 400;
    private final double MANUAL = 200;
    double price = 0;

    public I20(int longevity, String transmission) {
        this.longevity = longevity;
        this.transmission = transmission;
    }

    /**
     * @return price
     */
    public double getPrice() {
        return PRICE;
    }

    public int getLongevity() {
        return longevity;
    }

    /**
     * Method implemented to prove that a I20 object has been succesfully
     * created and can execute its methods.
     */
    public void drive() {
        System.out.println("I20 car just created!");
    }


    /*
     *Method that calculates the depreciation of a vehicle
     *@return  depreciation
     */
    public double depreciation() {
        if (transmission.equals("manual")) {
            return (PRICE - MANUAL) - (longevity * DEPRECIATION);
        } else {
            return (PRICE - AUTOMATIC) - (longevity * DEPRECIATION);

        }

    }

}
