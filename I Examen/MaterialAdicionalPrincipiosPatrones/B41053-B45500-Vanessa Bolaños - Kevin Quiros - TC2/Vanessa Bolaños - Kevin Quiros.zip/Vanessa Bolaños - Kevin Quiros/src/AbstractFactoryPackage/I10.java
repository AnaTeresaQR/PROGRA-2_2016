
package AbstractFactoryPackage;

/**
 * This class implements Car interface, so does every concrete class
 * representing a car.
 * @author Vanessa Bolaños Umaña
 * @author Kevin Quiros Acosta
 * @version 1.0
 */
public class I10 implements Car {

    private int longevity;  //year bought the car
    private String transmission; // type of  transmission of a car
    private final double PRICE = 10000;
    private final double AUTOMATIC = 500;
    private final double DEPRECIATION = 550 ;

    /**
     * Method constructor
     * @param longevity
     * @param transmission
     */
    public I10(int longevity, String transmission) {
        this.longevity = longevity;
        this.transmission = transmission;
    }

    public double getPRICE() {
        return PRICE;
    }

    public int getLongevity() {
        return longevity;
    }
    /**
     * Method implemented to prove that a I10 object has been succesfully
     * created and can execute its method
     */
    public void drive() {
        System.out.println("I10 car just created!");
    }

    /**
     * Method that calculate the depreciation
     * @return depreciation of the car
     */
    public double depreciation() {
        if (transmission.equals("manual")) {
            return (PRICE - (longevity * DEPRECIATION));
        } else {
            double price = PRICE - (longevity * DEPRECIATION);
            return price - AUTOMATIC;
        }

    }

}
