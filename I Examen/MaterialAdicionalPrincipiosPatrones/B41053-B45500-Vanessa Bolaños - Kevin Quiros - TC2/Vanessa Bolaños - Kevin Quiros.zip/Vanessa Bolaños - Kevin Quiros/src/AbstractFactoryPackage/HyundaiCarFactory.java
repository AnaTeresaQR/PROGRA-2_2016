/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AbstractFactoryPackage;

/**
 *@author Kevin Quiros Acosta
 *@author Usuario Vanessa Bolaños Umaña 
 *@version 1.0
 */
public class HyundaiCarFactory implements CarFactory{
    
     /**
      * this methods creates and returns a concrete object of type Car.
      *@return Car
      */
    
       public Car createCar(String type, int longevity , String transmission){
        try {
        if ("I10".equalsIgnoreCase(type)) {
            return new I10(longevity ,transmission );
        }
        if ("I20".equalsIgnoreCase(type)) {
            return new I20(longevity , transmission);
        }
        } catch (Exception exepction ) {
            System.out.println("Error ");
        }
        return null;
    }
}
